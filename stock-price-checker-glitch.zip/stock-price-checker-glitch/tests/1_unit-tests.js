/*
*
*
*       FILL IN EACH UNIT TEST BELOW COMPLETELY
*       -----[Keep the tests in the same order!]----
*       (if additional are added, keep them at the very end!)
*/

var chai = require('chai');
// var StockHandler = require('../controllers/stockHandler.js');

// var stockPrices = new StockHandler();

suite('Unit Tests', function(){

//none requiered

});